# Academic Profile

منصة شخصية أكاديمية متكاملة للباحثين والأساتذة والكتّاب — React + Vite + Tailwind + Supabase، تعمل بالكامل بدون خادم Backend مستقل، وقابلة للنشر على GitHub Pages.

A complete personal academic platform (blog, books, book requests, admin dashboard) — React + Vite + Tailwind + Supabase, no standalone backend, deployable to GitHub Pages.

---

## المزايا

- صفحة رئيسية سينمائية (Hero, About, Expertise, Featured Posts, Books, Links, Contact)
- مدونة كاملة: بحث، تصنيفات، مقالات ذات صلة، محرر Markdown مبسّط
- كتب بثلاثة أنواع: مجاني (تحميل PDF مباشر) / مدفوع (نموذج طلب) / عند الطلب
- لوحة تحكم محمية بـ Supabase Auth + RLS (إدارة التدوينات، الكتب، الطلبات، الملف الشخصي، الإعدادات، وضع الصيانة)
- ثلاث لغات: العربية (RTL)، الفرنسية، الإنجليزية
- PWA قابل للتثبيت + SEO ديناميكي (OG / Twitter Card / canonical)
- الأمان الحقيقي عبر Row Level Security — لا مفاتيح سرية في الواجهة أبداً

## 1) إنشاء مشروع Supabase

1. ادخل إلى https://supabase.com وأنشئ حساباً ثم **New project** (يعمل من الهاتف أيضاً).
2. اختر اسماً وكلمة مرور قاعدة البيانات ومنطقة قريبة، وانتظر دقيقة حتى يجهز المشروع.

## 2) تشغيل SQL

من القائمة الجانبية: **SQL Editor → New query** ثم الصق وشغّل بالترتيب:

1. محتوى `supabase/schema.sql` → **Run**
2. محتوى `supabase/storage.sql` → **Run**
3. محتوى `supabase/migrations/0001_multi_tenant.sql` → **Run** (بالترتيب — بعد schema وstorage)
4. محتوى `supabase/migrations/0002_security_hardening.sql` → **Run** (تحصينات العزل/التخزين)
5. محتوى `supabase/migrations/0003_verification_pdf_lockdown.sql` → **Run** (إغلاق تحقق الدومين + بوابة تحميل الكتب)
6. (إلزامي لتحقق الدومينات) `supabase functions deploy verify-domain` — التحقق الخادمي الوحيد؛ بدونه تبقى الدومينات `pending`

> **ملاحظة الـmigrations**: كل ملفات `migrations/*.sql` قابلة لإعادة التشغيل بأمان (`create ... if not exists` / `drop ... if exists` / `create or replace`). إن نفّذتها سابقاً فأعد تشغيل الجديد منها فقط؛ وللتأكد مما طُبّق: `select proname from pg_proc where proname in ('verify_domain_server','get_book_download');` — وجودهما يعني أن 0003 مطبّقة. لا تحذف الـmigrations أي بيانات أو ملفات أو روابط قديمة؛ الملفات غير المُبادئة بـ `tenants/{id}/` تبقى مقروءة للمديرين كما كانت.
3. (اختياري) محتوى `supabase/seed.sql` → **Run** لبيانات تجريبية قابلة للتعديل لاحقاً من لوحة التحكم.

## 3) إنشاء المستخدم المدير (Admin)

1. **Authentication → Users → Add user → Create new user**
2. أدخل بريدك وكلمة مرور قوية، وفعّل **Auto Confirm User** ثم Create.
3. انسخ **UUID** الخاص بالمستخدم من الجدول.
4. في SQL Editor شغّل:

```sql
insert into public.admin_users (user_id) values ('PASTE-USER-UUID-HERE');
```

## 4) مفاتيح المشروع

**Project Settings → API**:

- انسخ **Project URL** → `VITE_SUPABASE_URL`
- انسخ مفتاح **publishable** (يبدأ بـ `sb_publishable_`) → `VITE_SUPABASE_PUBLISHABLE_KEY` (أو anon القديم → `VITE_SUPABASE_ANON_KEY` — كلاهما مدعوم)

> لا تستخدم مفتاح `service_role` في الواجهة أبداً. مفتاح anon آمن لأن كل الجداول محمية بـ RLS.

## 5) التشغيل محلياً

```bash
cp .env.example .env      # ثم املأ المفتاحين داخل .env
npm install
npm run dev
```

بدون إعداد Supabase يعمل الموقع في **وضع تجريبي** ببيانات عرض فقط (للمعاينة).

## 6) النشر على GitHub Pages

1. أنشئ Repository وارفع الكود.
2. في المستودع: **Settings → Pages → Source: GitHub Actions**.
3. في **Settings → Secrets and variables → Actions → Variables** أضف متغيرين (Variables وليس Secrets — مفتاح anon عام بطبيعته):
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY` (أو `VITE_SUPABASE_ANON_KEY` للمشاريع القديمة)
4. ادفع إلى فرع `main` — سيبني الـ workflow الموجود في `.github/workflows/deploy.yml` وينشر تلقائياً.

الموقع يستخدم `base: './'` و HashRouter لذا يعمل من أي مسار (`user.github.io/repo/`) دون إعدادات إضافية.

## بنية المشروع

```
src/
  components/ (layout, home, blog, books, admin, ui)
  pages/      (public, admin)
  contexts/   (AuthContext, SiteContext)
  i18n/       (ar, en, fr)
  lib/        (supabase, api, markdown, format, demo-data)
  hooks/      (useSEO, useReveal)
  types/
supabase/     (schema.sql, storage.sql, seed.sql, migrations/, functions/verify-domain/)
.github/workflows/deploy.yml
```

## ملاحظات

- رفع الملفات (صور/PDF) يتم إلى Buckets: `profile`, `covers`, `previews` (قراءة عامة، كتابة للمدير فقط) و`books` (خاص — Private). الكتب المجانية تُحمَّل عبر Signed URL قصير المدة يُنشأ عند الضغط على "تحميل الكتاب"، أما كتب PAID/REQUEST فلا يظهر رابط PDF لها أصلاً للزوار.
- عند استبدال ملف قديم (صورة/غلاف/PDF) يُرفع الجديد أولاً ثم يُحذف القديم تلقائياً.
- طلبات الكتب محمية ضد السبام بـ honeypot + تحديد معدل (طلب واحد/دقيقة) + تحقق من المدخلات.
- وضع الصيانة يُفعَّل من Admin → Settings (معطّل افتراضياً).

---

## Multi-Tenant Architecture

المنصة تدعم عدداً غير محدود من المواقع الأكاديمية على نفس التطبيق ونفس مشروع Supabase:

```
المنصة (Superadmin)
 ├── Tenant A (professor-a.com)
 ├── Tenant B (professor-b.com)
 └── Tenant C (#/site/researcher-c على GitHub Pages)
```

- **Superadmin**: عضو `tenant_members` بـ `role='superadmin'` (tenant_id = NULL). يرى `/admin/tenants`، ينشئ/يعلّق/يحذف المواقع، ويدير الدومينات، ويفتح أي موقع للإدارة (سياق "Open Tenant" داخل التطبيق — بدون مشاركة كلمات مرور).
- **Client Admin**: عضو بـ `role='admin'` مرتبط بـtenant واحد. يرى لوحة موقعه فقط. العزل كامل عبر RLS (`is_tenant_admin(tenant_id)`) — إرسال tenant_id لموقع آخر يفشل على مستوى Postgres (WITH CHECK)، وليس في الواجهة فقط.
- **الجداول**: `tenants`, `tenant_members`, `tenant_domains`، وكل جداول المحتوى (`profiles, posts, books, book_requests, site_settings`) تحمل `tenant_id`.
- **القراءات العامة (0002)**: الاستعلام المباشر عبر API يعرض محتوى الـtenant الافتراضي فقط؛ محتوى بقية الـtenants المنشور يُقدَّم حصرياً عبر RPCs (`list_public_posts`, `list_public_books`, `get_public_profile`, `get_public_settings`...) تتحقق في الخادم أن الـtenant بحالة `active` — فلا يمكن تعداد محتوى tenant معلّق/مخفي، ولا قراءة مسوداته.
- **الطلبات**: قاعدة البيانات ترفض أي `book_requests` لا يتطابق فيها `book_id` مع `tenant_id` (أو لكتاب غير منشور/مجاني).
- **تحميل الكتب (0003)**: أهلية التحميل المجاني تُقرَّر في الخادم عبر `get_book_download(tenant, book)` — tenant نشط + الكتاب يتبعه + منشور + FREE، وإلا NULL. ثم سياسة التخزين تفرض تطابق المسار الحرفي عند توقيع URL. كتب PAID/REQUEST لا تُعيد شيئًا للزائر إطلاقًا.
- **Storage**: الملفات الجديدة تحت `tenants/{tenant_id}/...` وسياسات التخزين تمنع الوصول المتقاطع. bucket الكتب يبقى private — توقيع URL لكتب FREE يتطلب تطابق مسار الملف **حرفياً** مع `pdf_url` + انتماء الكتاب للـtenant المُرمَّز في المسار + الكتاب منشور (لا يمكن للزائر توقيع كتب PAID/REQUEST).

### إنشاء أول Superadmin

```sql
insert into public.tenant_members (tenant_id, user_id, role)
values (null, 'YOUR-USER-UUID', 'superadmin');
```

### إضافة عميل جديد

1. Superadmin → `/admin/tenants` → إنشاء موقع أكاديمي (الاسم، slug، بريد العميل).
2. العميل يسجّل حساباً بنفس البريد — trigger يربط عضويته تلقائياً (لا كلمات مرور في قاعدة البيانات، لا service_role).
3. يحصل العميل على Profile وSettings افتراضية جاهزة.

## Custom Domain Setup

1. Superadmin → Tenant → Domains → أضف `client-domain.com`.
2. يظهر سجل DNS المطلوب: `TXT  _academic-verification.client-domain.com  <token>`.
3. العميل يضيفه لدى مزود DNS ثم يضغط **تحقق**. التحقق مسار **واحد موثوق** (0003): انشر Edge Function المرفقة أولاً: `supabase functions deploy verify-domain` — تُوثّق المستخدم من جلسته الحقيقية، تتحقق من عضويته في tenant الدومين **من الخادم**، تستعلم DNS TXT عبر `Deno.resolveDns` من الخادم، وتشترط **تطابقًا حرفيًا كاملاً** بين السجل والتوكن، ثم تستدعي `verify_domain_server` — دالة **مُسحوبة التنفيذ من PUBLIC/anon/authenticated** ومتاحة حصرياً لـ `service_role` (مفتاح موجود فقط في بيئة الـ Edge Function، ولا يوجد في المستودع ولا في الواجهة إطلاقاً). إن لم تكن الـFunction منشورة أو تعذّر الوصول إليها: يفشل التحقق ويبقى الدومين `pending` — **لا يوجد أي بديل من المتصفح**. قيود DB تمنع `active` قبل `verified_at`.
4. فعّل الدومين (Active) وعيّنه Primary (مؤشر فريد في قاعدة البيانات يضمن primary واحداً فقط لكل tenant).
5. أضف الدومين في GitHub Pages: Settings → Pages → Custom domain (وإلا فلن يقدّم GitHub الموقع على هذا النطاق حتى لو كان موثقاً).
6. عند زيارة `client-domain.com` يتعرف التطبيق على الـtenant من `window.location.hostname` عبر `resolve_tenant_by_hostname` ويعرض محتواه فقط. دومين pending/disabled يعرض صفحة "الموقع غير متاح".

> ملاحظة صادقة: تسجيل الدومين في قاعدة البيانات وحده لا يجعل النطاق يعمل — يلزم DNS (CNAME/A) + إعداد GitHub Pages.
