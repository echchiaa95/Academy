import { lazy, Suspense } from 'react'
import { Routes, Route, useLocation } from 'react-router'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { useT } from '@/i18n'

const HomePage = lazy(() => import('@/pages/public/HomePage'))
const AboutPage = lazy(() => import('@/pages/public/AboutPage'))
const BlogPage = lazy(() => import('@/pages/public/BlogPage'))
const BlogPostPage = lazy(() => import('@/pages/public/BlogPostPage'))
const BooksPage = lazy(() => import('@/pages/public/BooksPage'))
const BookDetailPage = lazy(() => import('@/pages/public/BookDetailPage'))
const ContactPage = lazy(() => import('@/pages/public/ContactPage'))
const NotFoundPage = lazy(() => import('@/pages/public/NotFoundPage'))
const AdminLayout = lazy(() => import('@/components/admin/AdminLayout').then((m) => ({ default: m.AdminLayout })))
const RequireAdmin = lazy(() => import('@/pages/admin/RequireAdmin').then((m) => ({ default: m.RequireAdmin })))
const DashboardPage = lazy(() => import('@/pages/admin/DashboardPage'))
const PostsAdminPage = lazy(() => import('@/pages/admin/PostsAdminPage'))
const PostEditorPage = lazy(() => import('@/pages/admin/PostEditorPage'))
const BooksAdminPage = lazy(() => import('@/pages/admin/BooksAdminPage'))
const BookEditorPage = lazy(() => import('@/pages/admin/BookEditorPage'))
const RequestsAdminPage = lazy(() => import('@/pages/admin/RequestsAdminPage'))
const ProfileAdminPage = lazy(() => import('@/pages/admin/ProfileAdminPage'))
const SettingsAdminPage = lazy(() => import('@/pages/admin/SettingsAdminPage'))
const TenantsAdminPage = lazy(() => import('@/pages/admin/TenantsAdminPage'))
const TenantFormPage = lazy(() => import('@/pages/admin/TenantFormPage'))
const TenantDomainsPage = lazy(() => import('@/pages/admin/TenantDomainsPage'))
const RequireSuperadmin = lazy(() => import('@/pages/admin/RequireSuperadmin').then((m) => ({ default: m.RequireSuperadmin })))
const SiteRedirectPage = lazy(() => import('@/pages/public/SiteRedirectPage'))

function Loader() {
  const t = useT()
  return <div className="flex min-h-[60vh] items-center justify-center text-muted-foreground">{t.states.loading}</div>
}

export default function App() {
  const loc = useLocation()
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <Suspense fallback={<Loader />}>
        <Routes location={loc}>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:slug" element={<BlogPostPage />} />
          <Route path="/books" element={<BooksPage />} />
          <Route path="/books/:slug" element={<BookDetailPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/site/:slug" element={<SiteRedirectPage />} />
          <Route element={<RequireAdmin />}>
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<DashboardPage />} />
              <Route path="posts" element={<PostsAdminPage />} />
              <Route path="posts/new" element={<PostEditorPage />} />
              <Route path="posts/:id" element={<PostEditorPage />} />
              <Route path="books" element={<BooksAdminPage />} />
              <Route path="books/new" element={<BookEditorPage />} />
              <Route path="books/:id" element={<BookEditorPage />} />
              <Route path="requests" element={<RequestsAdminPage />} />
              <Route path="profile" element={<ProfileAdminPage />} />
              <Route path="settings" element={<SettingsAdminPage />} />
              <Route element={<RequireSuperadmin />}>
                <Route path="tenants" element={<TenantsAdminPage />} />
                <Route path="tenants/new" element={<TenantFormPage />} />
                <Route path="tenants/:id" element={<TenantFormPage />} />
                <Route path="tenants/:id/domains" element={<TenantDomainsPage />} />
              </Route>
            </Route>
          </Route>
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
      <Footer />
    </div>
  )
}
