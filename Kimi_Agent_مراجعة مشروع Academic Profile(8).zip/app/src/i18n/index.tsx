import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { ar, type Dict } from './ar'
import { en } from './en'
import { fr } from './fr'

export type Lang = 'ar' | 'en' | 'fr'
const dicts: Record<Lang, Dict> = { ar, en, fr }

type LangCtx = { lang: Lang; setLang: (l: Lang) => void; t: Dict; dir: 'rtl' | 'ltr' }
const Ctx = createContext<LangCtx>({ lang: 'ar', setLang: () => {}, t: ar, dir: 'rtl' })

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = localStorage.getItem('lang') as Lang | null
    return saved && dicts[saved] ? saved : 'ar'
  })
  const dir = lang === 'ar' ? 'rtl' : 'ltr'
  useEffect(() => {
    document.documentElement.lang = lang
    document.documentElement.dir = dir
    localStorage.setItem('lang', lang)
  }, [lang, dir])
  return <Ctx.Provider value={{ lang, setLang: setLangState, t: dicts[lang], dir }}>{children}</Ctx.Provider>
}

export const useLang = () => useContext(Ctx)
export const useT = () => useContext(Ctx).t
