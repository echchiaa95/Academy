import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router'
import { Menu, X, Globe, LayoutDashboard } from 'lucide-react'
import { useLang } from '@/i18n'
import { useAuth } from '@/contexts/AuthContext'
import { useSite } from '@/contexts/SiteContext'
import { cn } from '@/lib/utils'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'

const links = [
  { to: '/', key: 'home' }, { to: '/about', key: 'about' }, { to: '/blog', key: 'blog' },
  { to: '/books', key: 'books' }, { to: '/#links', key: 'research' }, { to: '/contact', key: 'contact' },
] as const

export function Navbar() {
  const { t } = useLang()
  const { isAdmin } = useAuth()
  const { settings } = useSite()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const loc = useLocation()

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 24)
    on(); window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])
  useEffect(() => setOpen(false), [loc])

  const go = (to: string) => (e: React.MouseEvent) => {
    if (to.startsWith('/#')) {
      e.preventDefault()
      document.getElementById('links')?.scrollIntoView({ behavior: 'smooth' })
      setOpen(false)
    }
  }

  return (
    <header className={cn('fixed inset-x-0 top-0 z-50 transition-all duration-500', scrolled ? 'glass shadow-lg shadow-black/20' : 'bg-transparent')}>
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
        <Link to="/" className="font-display text-xl font-semibold tracking-wide gold-text">
          {settings?.site_name || 'Academic Profile'}
        </Link>
        <div className="hidden items-center gap-7 md:flex">
          {links.map((l) => (
            <Link key={l.key} to={l.to} onClick={go(l.to)}
              className={cn('text-sm text-muted-foreground transition-colors hover:text-foreground',
                loc.pathname === l.to && 'text-foreground')}>
              {t.nav[l.key as keyof typeof t.nav]}
            </Link>
          ))}
          {isAdmin && (
            <Link to="/admin" className="flex items-center gap-1.5 rounded-full border border-[#c8a45c]/40 px-3.5 py-1.5 text-sm gold-text hover:bg-[#c8a45c]/10 transition-colors">
              <LayoutDashboard className="size-4" /> {t.nav.dashboard}
            </Link>
          )}
          <LangMenu />
        </div>
        <div className="flex items-center gap-2 md:hidden">
          <LangMenu />
          <button onClick={() => setOpen(!open)} aria-label="menu" className="p-2 text-foreground">
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </nav>
      {open && (
        <div className="glass border-t border-border/50 md:hidden">
          <div className="flex flex-col px-6 py-4 gap-1">
            {links.map((l) => (
              <Link key={l.key} to={l.to} onClick={go(l.to)} className="py-2.5 text-base text-muted-foreground hover:text-foreground">
                {t.nav[l.key as keyof typeof t.nav]}
              </Link>
            ))}
            {isAdmin && (
              <Link to="/admin" className="py-2.5 text-base gold-text flex items-center gap-2">
                <LayoutDashboard className="size-4" /> {t.nav.dashboard}
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  )
}

function LangMenu() {
  const { t, lang, setLang } = useLang()
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <Globe className="size-4" /> <span className="uppercase text-xs tracking-wider">{lang}</span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="glass">
        {(['ar', 'fr', 'en'] as const).map((l) => (
          <DropdownMenuItem key={l} onClick={() => setLang(l)} className={l === lang ? 'gold-text' : ''}>{t.lang[l]}</DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
