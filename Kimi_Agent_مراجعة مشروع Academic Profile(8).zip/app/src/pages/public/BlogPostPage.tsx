import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router'
import { ArrowRight, ArrowLeft } from 'lucide-react'
import { useLang, useT } from '@/i18n'
import { getPostBySlug, listPosts } from '@/lib/api'
import { renderMarkdown } from '@/lib/markdown'
import { formatDate, readingMinutes } from '@/lib/format'
import { useSite } from '@/contexts/SiteContext'
import { BlogCard } from '@/components/blog/BlogCard'
import { ImagePlaceholder } from '@/components/ui/placeholder'
import { TextSkeleton } from '@/components/ui/skeletons'
import { Button } from '@/components/ui/button'
import { useSEO } from '@/hooks/useSEO'
import type { Post } from '@/types'

export default function BlogPostPage() {
  const { slug } = useParams()
  const t = useT()
  const { lang, dir } = useLang()
  const { profile, tenant } = useSite()
  const [post, setPost] = useState<Post | null | undefined>(undefined)
  const [related, setRelated] = useState<Post[]>([])
  const Back = dir === 'rtl' ? ArrowRight : ArrowLeft

  useEffect(() => {
    setPost(undefined)
    getPostBySlug(slug!, tenant?.tenant_id).then((p) => {
      setPost(p)
      if (p) listPosts(tenant?.tenant_id, { publishedOnly: true }).then((all) =>
        setRelated(all.filter((x) => x.id !== p.id && (x.category === p.category || x.tags?.some((tg) => p.tags?.includes(tg)))).slice(0, 3)))
    })
  }, [slug, lang, tenant?.tenant_id])

  useSEO({
    title: post ? `${post.title} — ${profile ? `${profile.first_name} ${profile.last_name}` : ''}` : undefined,
    description: post?.excerpt, image: post?.cover_url || undefined, path: `/blog/${slug}`,
  })

  if (post === undefined) return <div className="mx-auto max-w-3xl px-5 py-32"><TextSkeleton lines={10} /></div>
  if (post === null) return (
    <div className="mx-auto max-w-3xl px-5 py-40 text-center space-y-4">
      <h1 className="font-display text-4xl">{t.states.notFound}</h1>
      <Button asChild variant="outline"><Link to="/blog">{t.blog.back}</Link></Button>
    </div>
  )

  const author = profile ? `${profile.first_name} ${profile.last_name}` : ''
  return (
    <main className="pb-20">
      <div className="relative">
        <div className="relative mx-auto max-w-5xl overflow-hidden md:rounded-b-2xl aspect-[16/7]">
          {post.cover_url
            ? <img src={post.cover_url} alt={post.title} className="size-full object-cover" />
            : <ImagePlaceholder className="size-full" />}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        </div>
        <div className="relative mx-auto max-w-3xl px-5">
          <div className="-mt-24 relative space-y-4">
            <Button asChild variant="ghost" size="sm" className="text-muted-foreground"><Link to="/blog"><Back className="size-4" /> {t.blog.back}</Link></Button>
            {post.category && <span className="block w-fit rounded-full glass px-3 py-1 text-xs gold-text">{post.category}</span>}
            <h1 className="font-display text-4xl md:text-5xl font-semibold leading-tight">{post.title}</h1>
            <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              {author && <span>{t.blog.by} <span className="text-foreground">{author}</span></span>}
              <span className="size-1 rounded-full bg-border" />
              <time>{formatDate(post.published_at, lang)}</time>
              <span className="size-1 rounded-full bg-border" />
              <span>{readingMinutes(post.content)} {t.blog.minRead}</span>
            </div>
          </div>
          <article className="article-body mt-10">{renderMarkdown(post.content)}</article>
          {post.tags?.length > 0 && (
            <div className="mt-10 flex flex-wrap gap-2">
              {post.tags.map((tg) => <span key={tg} className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">#{tg}</span>)}
            </div>
          )}
          {profile && (
            <div className="mt-12 flex items-center gap-4 rounded-xl glass p-5">
              <div className="size-16 shrink-0 overflow-hidden rounded-full">
                {profile.avatar_url ? <img src={profile.avatar_url} alt={author} className="size-full object-cover" /> : <ImagePlaceholder kind="portrait" className="size-full" />}
              </div>
              <div>
                <p className="font-display text-lg font-semibold">{author}</p>
                <p className="text-sm text-muted-foreground">{profile.academic_title}{profile.institution ? ` — ${profile.institution}` : ''}</p>
              </div>
            </div>
          )}
          {related.length > 0 && (
            <div className="mt-16">
              <h2 className="font-display text-2xl font-semibold mb-6">{t.blog.related}</h2>
              <div className="grid gap-8 md:grid-cols-3">{related.map((p) => <BlogCard key={p.id} post={p} />)}</div>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
