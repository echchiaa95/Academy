import { useEffect } from 'react'
import { useNavigate, useParams } from 'react-router'
import { setSiteSlugOverride } from '@/lib/tenant'
import { useSite } from '@/contexts/SiteContext'
import { useT } from '@/i18n'

// #/site/:slug — selects a tenant on platform hosts (GitHub Pages),
// then redirects to the homepage of that tenant's site.
export default function SiteRedirectPage() {
  const { slug } = useParams()
  const nav = useNavigate()
  const { refresh } = useSite()
  const t = useT()
  useEffect(() => {
    setSiteSlugOverride(slug ?? null)
    refresh().finally(() => nav('/', { replace: true }))
  }, [slug])
  return <div className="flex min-h-[70vh] items-center justify-center text-muted-foreground">{t.states.loading}</div>
}
