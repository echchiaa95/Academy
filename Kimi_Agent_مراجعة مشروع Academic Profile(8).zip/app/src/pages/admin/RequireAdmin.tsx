import { Navigate, Outlet } from 'react-router'
import { useAuth } from '@/contexts/AuthContext'
import { useT } from '@/i18n'
import LoginPage from './LoginPage'

// Route gate: any authenticated tenant member may enter /admin;
// WHAT they can see/change inside is enforced per-tenant by Postgres RLS
// (is_tenant_admin / is_superadmin) — never by this UI check alone.
export function RequireAdmin() {
  const { user, isAdmin, loading } = useAuth()
  const t = useT()
  if (loading) return <div className="flex min-h-screen items-center justify-center text-muted-foreground">{t.states.loading}</div>
  if (!user) return <LoginPage />
  if (!isAdmin) return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center">
      <p className="text-muted-foreground">{t.admin.notAdmin}</p>
      <Navigate to="/" replace />
    </div>
  )
  return <Outlet />
}
