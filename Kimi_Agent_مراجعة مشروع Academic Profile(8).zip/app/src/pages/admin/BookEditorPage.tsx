import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'
import { toast } from 'sonner'
import { useT } from '@/i18n'
import { upsertBook, listBooks } from '@/lib/api'
import { useAdminTenantId } from '@/hooks/useAdminTenant'
import { slugify } from '@/lib/format'
import { UploadField } from '@/components/admin/UploadField'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { Book, BookType } from '@/types'

const empty: Partial<Book> = { title: '', slug: '', description: '', author: '', year: null, pages: null, cover_url: '', pdf_url: '', preview_url: '', price: null, currency: 'USD', type: 'FREE', published: false, featured: false, featured_order: 0 }

export default function BookEditorPage() {
  const { id } = useParams()
  const isNew = !id || id === 'new'
  const t = useT()
  const nav = useNavigate()
  const [form, setForm] = useState<Partial<Book>>(empty)
  const [busy, setBusy] = useState(false)
  const tid = useAdminTenantId()

  useEffect(() => { if (!isNew) listBooks(tid).then((all) => { const b = all.find((x) => x.id === id); if (b) setForm(b) }) }, [id])
  const set = (k: keyof Book, v: any) => setForm((f) => ({ ...f, [k]: v }))

  async function save() {
    if (!form.title) { toast.error(t.admin.form.title); return }
    setBusy(true)
    try {
      const payload = { ...form, tenant_id: (form as any).tenant_id ?? tid, slug: form.slug || slugify(form.title), year: form.year || null, pages: form.pages || null, price: form.price ?? null }
      const savedId = await upsertBook(payload as any)
      toast.success(t.admin.saved)
      if (isNew) nav(`/admin/books/${savedId}`, { replace: true })
    } catch { toast.error(t.admin.saveError) }
    finally { setBusy(false) }
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl gold-text">{isNew ? t.admin.new : t.admin.edit} — {t.admin.books}</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => nav('/admin/books')}>{t.admin.back}</Button>
          <Button onClick={save} disabled={busy} className="bg-[#c8a45c] text-stone-900 hover:bg-[#d9b56e]">{busy ? t.admin.saving : isNew ? t.admin.create : t.admin.update}</Button>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5"><Label>{t.admin.form.title} *</Label><Input value={form.title ?? ''} onChange={(e) => set('title', e.target.value)} /></div>
        <div className="space-y-1.5"><Label>{t.admin.form.slug}</Label><Input dir="ltr" value={form.slug ?? ''} onChange={(e) => set('slug', e.target.value)} placeholder={slugify(form.title ?? '')} /></div>
        <div className="space-y-1.5"><Label>{t.admin.form.author}</Label><Input value={form.author ?? ''} onChange={(e) => set('author', e.target.value)} /></div>
        <div className="space-y-1.5"><Label>{t.admin.form.type}</Label>
          <Select value={form.type} onValueChange={(v) => set('type', v as BookType)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="FREE">{t.admin.types.FREE}</SelectItem>
              <SelectItem value="PAID">{t.admin.types.PAID}</SelectItem>
              <SelectItem value="REQUEST">{t.admin.types.REQUEST}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5"><Label>{t.admin.form.yearLabel}</Label><Input type="number" dir="ltr" value={form.year ?? ''} onChange={(e) => set('year', e.target.value ? +e.target.value : null)} /></div>
        <div className="space-y-1.5"><Label>{t.admin.form.pages}</Label><Input type="number" dir="ltr" value={form.pages ?? ''} onChange={(e) => set('pages', e.target.value ? +e.target.value : null)} /></div>
        {form.type === 'PAID' && (<>
          <div className="space-y-1.5"><Label>{t.admin.form.price}</Label><Input type="number" step="0.01" dir="ltr" value={form.price ?? ''} onChange={(e) => set('price', e.target.value ? +e.target.value : null)} /></div>
          <div className="space-y-1.5"><Label>{t.admin.form.currency}</Label><Input dir="ltr" value={form.currency ?? 'USD'} onChange={(e) => set('currency', e.target.value)} /></div>
        </>)}
        <div className="space-y-1.5"><Label>{t.admin.form.featuredOrder}</Label><Input type="number" dir="ltr" value={form.featured_order ?? 0} onChange={(e) => set('featured_order', +e.target.value)} /></div>
        <div className="flex items-end gap-8 pb-1">
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!form.published} onCheckedChange={(v) => set('published', v)} /> {t.admin.form.published}</label>
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!form.featured} onCheckedChange={(v) => set('featured', v)} /> {t.admin.form.featured}</label>
        </div>
      </div>
      <div className="space-y-1.5"><Label>{t.admin.form.description}</Label><Textarea rows={5} value={form.description ?? ''} onChange={(e) => set('description', e.target.value)} /></div>
      <UploadField bucket="covers" accept="image/*" value={form.cover_url ?? ''} onChange={(u) => set('cover_url', u)} label={t.admin.form.cover} />
      <UploadField bucket="books" accept="application/pdf" value={form.pdf_url ?? ''} onChange={(u) => set('pdf_url', u)} label={t.admin.form.pdf} />
      <UploadField bucket="previews" accept="application/pdf,image/*" value={form.preview_url ?? ''} onChange={(u) => set('preview_url', u)} label={t.admin.form.previewFile} />
    </div>
  )
}
