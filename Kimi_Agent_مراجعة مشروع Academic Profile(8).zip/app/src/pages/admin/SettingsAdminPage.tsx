import { useEffect, useState } from 'react'
import { toast } from 'sonner'
import { useT } from '@/i18n'
import { getSettings, updateSettings } from '@/lib/api'
import { useAdminTenantId } from '@/hooks/useAdminTenant'
import { useSite } from '@/contexts/SiteContext'
import { UploadField } from '@/components/admin/UploadField'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import type { SiteSettings } from '@/types'

export default function SettingsAdminPage() {
  const t = useT()
  const { refresh } = useSite()
  const [form, setForm] = useState<SiteSettings | null>(null)
  const [busy, setBusy] = useState(false)
  const tid = useAdminTenantId()
  useEffect(() => { getSettings(tid).then(setForm) }, [tid])
  if (!form) return <p className="text-muted-foreground">{t.states.loading}</p>
  const set = (k: keyof SiteSettings, v: any) => setForm((f) => f && { ...f, [k]: v })

  async function save() {
    setBusy(true)
    try { await updateSettings(form as SiteSettings); await refresh(); toast.success(t.admin.saved) }
    catch { toast.error(t.admin.saveError) }
    finally { setBusy(false) }
  }

  const Toggle = ({ k, label }: { k: keyof SiteSettings; label: string }) => (
    <label className="flex items-center justify-between rounded-lg border border-border/60 px-4 py-3 text-sm">
      {label}
      <Switch checked={Boolean(form[k])} onCheckedChange={(v) => set(k, v)} />
    </label>
  )

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl gold-text">{t.admin.settings}</h1>
        <Button onClick={save} disabled={busy} className="bg-[#c8a45c] text-stone-900 hover:bg-[#d9b56e]">{busy ? t.admin.saving : t.admin.save}</Button>
      </div>
      <div className="space-y-1.5"><Label>{t.admin.form.siteName}</Label><Input value={form.site_name ?? ''} onChange={(e) => set('site_name', e.target.value)} /></div>
      <div className="space-y-1.5"><Label>{t.admin.form.siteDesc}</Label><Textarea rows={2} value={form.site_description ?? ''} onChange={(e) => set('site_description', e.target.value)} /></div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5"><Label>{t.admin.form.postsPerPage}</Label><Input type="number" min={1} max={12} dir="ltr" value={form.posts_per_page} onChange={(e) => set('posts_per_page', +e.target.value)} /></div>
        <div className="space-y-1.5"><Label>{t.admin.form.booksPerPage}</Label><Input type="number" min={1} max={12} dir="ltr" value={form.books_per_page} onChange={(e) => set('books_per_page', +e.target.value)} /></div>
      </div>
      <UploadField bucket="profile" accept="image/*" value={form.hero_image_url ?? ''} onChange={(u) => set('hero_image_url', u)} label={t.admin.form.heroImage} />
      <div className="space-y-2">
        <Toggle k="show_about" label={t.admin.form.showAbout} />
        <Toggle k="show_blog" label={t.admin.form.showBlog} />
        <Toggle k="show_books" label={t.admin.form.showBooks} />
        <Toggle k="show_social" label={t.admin.form.showSocial} />
        <Toggle k="show_contact" label={t.admin.form.showContact} />
      </div>
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 space-y-2">
        <Toggle k="maintenance_mode" label={t.admin.form.maintenance} />
        <p className="text-xs text-muted-foreground">{t.admin.form.maintenanceHint}</p>
      </div>
    </div>
  )
}
