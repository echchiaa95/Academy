import { createContext, useContext, useEffect, useState, type ReactNode, useCallback } from 'react'
import { getProfile, getSettings } from '@/lib/api'
import { resolveCurrentTenant } from '@/lib/tenant'
import { useLang } from '@/i18n'
import type { Profile, SiteSettings, TenantResolution } from '@/types'

type SiteCtx = {
  profile: Profile | null
  settings: SiteSettings | null
  tenant: TenantResolution | null
  unavailable: boolean
  loading: boolean
  refresh: () => Promise<void>
}
const Ctx = createContext<SiteCtx>({ profile: null, settings: null, tenant: null, unavailable: false, loading: true, refresh: async () => {} })
export const useSite = () => useContext(Ctx)

export function SiteProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [settings, setSettings] = useState<SiteSettings | null>(null)
  const [tenant, setTenant] = useState<TenantResolution | null>(null)
  const [unavailable, setUnavailable] = useState(false)
  const [loading, setLoading] = useState(true)
  const { lang } = useLang()

  const refresh = useCallback(async () => {
    const { tenant: t, unavailable: ua } = await resolveCurrentTenant().catch(() => ({ tenant: null, unavailable: false }))
    setTenant(t); setUnavailable(ua)
    const [p, s] = await Promise.all([
      getProfile(t?.tenant_id).catch(() => null),
      getSettings(t?.tenant_id).catch(() => null),
    ])
    setProfile(p); setSettings(s); setLoading(false)
  }, [])

  // refetch when the language changes so demo content switches language too
  useEffect(() => { refresh() }, [refresh, lang])
  return <Ctx.Provider value={{ profile, settings, tenant, unavailable, loading, refresh }}>{children}</Ctx.Provider>
}
