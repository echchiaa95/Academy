import { useEffect } from 'react'

// Reveal-on-scroll: add class "reveal" to any element; it animates in when visible.
export function useReveal(dep: unknown[] = []) {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal:not(.is-visible)')
    if (!('IntersectionObserver' in window)) { els.forEach((e) => e.classList.add('is-visible')); return }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target) } })
    }, { threshold: 0.12 })
    els.forEach((e) => io.observe(e))
    return () => io.disconnect()
  }, dep)
}
