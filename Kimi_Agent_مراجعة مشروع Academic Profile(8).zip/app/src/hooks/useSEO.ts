import { useEffect } from 'react'

function setMeta(attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`)
  if (!el) { el = document.createElement('meta'); el.setAttribute(attr, key); document.head.appendChild(el) }
  el.content = content
}

export function useSEO(opts: { title?: string; description?: string; image?: string; path?: string }) {
  useEffect(() => {
    const { title, description, image, path } = opts
    const url = location.origin + location.pathname + (path ? `#${path}` : '')
    if (title) { document.title = title; setMeta('property', 'og:title', title); setMeta('name', 'twitter:title', title) }
    if (description) { setMeta('name', 'description', description); setMeta('property', 'og:description', description); setMeta('name', 'twitter:description', description) }
    setMeta('property', 'og:type', 'website')
    setMeta('property', 'og:url', url)
    setMeta('name', 'twitter:card', image ? 'summary_large_image' : 'summary')
    if (image) { setMeta('property', 'og:image', image); setMeta('name', 'twitter:image', image) }
    let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]')
    if (!link) { link = document.createElement('link'); link.rel = 'canonical'; document.head.appendChild(link) }
    link.href = url
  }, [opts.title, opts.description, opts.image, opts.path])
}
