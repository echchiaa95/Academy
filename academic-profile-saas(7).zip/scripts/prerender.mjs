// Build-time prerenderer — gives every published post/book/language version a REAL,
// directly fetchable URL (no hash) so search engines can index each language page
// independently. Hash-fragment URLs (/#/blog/x) all map to one SPA document and are
// NOT reliably indexable as separate pages — this script is the fix for that.
//
// Output: public/p/<type>/<lang>/<slug>/index.html — static HTML with full content,
// correct meta/canonical/hreflang/JSON-LD, and a link into the SPA. No redirect tricks.
// Runs in CI BEFORE `vite build` (public/ is copied into dist/). Requires:
//   VITE_SUPABASE_URL, VITE_SUPABASE_PUBLISHABLE_KEY (public RPCs only), SITE_BASE_URL.
// Without env it exits cleanly and the SPA keeps working exactly as before.
import { mkdirSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'

const url = process.env.VITE_SUPABASE_URL
const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_ANON_KEY
const BASE = (process.env.SITE_BASE_URL || '').replace(/\/$/, '')

const LANGS = ['ar', 'fr', 'en']
const DIR = { ar: 'rtl', fr: 'ltr', en: 'ltr' }

function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}
function md(mdText) {
  // minimal markdown → HTML for the static snapshot (headings, bold, paragraphs)
  return esc(mdText ?? '')
    .replace(/^### (.*)$/gm, '<h3>$1</h3>').replace(/^## (.*)$/gm, '<h2>$1</h2>').replace(/^# (.*)$/gm, '<h1>$1</h1>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .split(/\n{2,}/).map((p) => /^<h\d>/.test(p) ? p : `<p>${p.replace(/\n/g, '<br>')}</p>`).join('\n')
}

async function rpc(fn, body) {
  const r = await fetch(`${url}/rest/v1/rpc/${fn}`, {
    method: 'POST',
    headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!r.ok) throw new Error(`${fn}: HTTP ${r.status}`)
  return r.json()
}
async function rest(table, query) {
  const r = await fetch(`${url}/rest/v1/${table}?${query}`, { headers: { apikey: key, Authorization: `Bearer ${key}` } })
  if (!r.ok) return []
  return r.json()
}

function page({ lang, title, description, canonical, alternates, jsonLd, bodyHtml }) {
  const alt = alternates.map((a) => `  <link rel="alternate" hreflang="${a.lang}" href="${esc(a.href)}">`).join('\n')
  const xd = alternates.length ? `  <link rel="alternate" hreflang="x-default" href="${esc(alternates[0].href)}">` : ''
  return `<!doctype html>
<html lang="${lang}" dir="${DIR[lang]}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(description)}">
<meta name="robots" content="index,follow">
<link rel="canonical" href="${esc(canonical)}">
${alt}
${xd}
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:url" content="${esc(canonical)}">
<meta property="og:type" content="article">
<script type="application/ld+json">${JSON.stringify(jsonLd).replace(/</g, '\\u003c')}</script>
<style>
  body{font-family:Georgia,'Times New Roman',serif;max-width:44rem;margin:3rem auto;padding:0 1.25rem;line-height:1.9;color:#1c1917;background:#fafaf9}
  h1{line-height:1.3} a{color:#8a6d2f} .meta{color:#78716c;font-size:.9rem;margin-bottom:2rem}
  nav{margin-bottom:2rem;font-size:.95rem}
</style>
</head>
<body>
<nav><a href="${esc(BASE)}/">⌂</a> · <a href="${esc(BASE)}/#${lang === 'ar' ? '' : ''}">Open the interactive site</a></nav>
${bodyHtml}
</body>
</html>
`
}

function write(path, html) {
  const p = `public/${path}`
  mkdirSync(dirname(p), { recursive: true })
  writeFileSync(p, html)
}

async function main() {
  if (!url || !key || !BASE) {
    console.log('[prerender] env missing (VITE_SUPABASE_URL / key / SITE_BASE_URL) — skipped; SPA unchanged')
    return
  }
  // resolve the default tenant server-side (browser input never decides this)
  const tidRes = await fetch(`${url}/rest/v1/rpc/default_tenant_id`, {
    method: 'POST', headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: '{}',
  })
  if (!tidRes.ok) throw new Error(`default_tenant_id: HTTP ${tidRes.status}`)
  const tenantId = await tidRes.json()
  if (!tenantId) { console.log('[prerender] no default tenant — skipped'); return }
  const profRows = await rpc('get_public_profile', { p_tenant_id: tenantId })
  const owner = profRows?.[0] ?? {}
  const authorName = `${owner.first_name ?? ''} ${owner.last_name ?? ''}`.trim()
  let count = 0

  const posts = await rpc('list_public_posts', { p_tenant_id: tenantId, p_featured: false, p_limit: 500 })
  const books = await rpc('list_public_books', { p_tenant_id: tenantId, p_featured: false, p_limit: 500 })
  const postTrs = await rest('post_translations', `tenant_id=eq.${tenantId}&published=eq.true`)
  const bookTrs = await rest('book_translations', `tenant_id=eq.${tenantId}&published=eq.true`)

  // group available language versions per entity: { entityId: { lang: {slug,title,...} } }
  function versions(base, trs, kind) {
    const v = {}
    const bl = base.language_code || 'ar'
    v[bl] = { slug: base.slug, title: base.title, body: kind === 'post' ? base.content : base.description, excerpt: base.excerpt || base.description, date: base.published_at, image: base.cover_url }
    for (const tr of trs.filter((t) => (kind === 'post' ? t.post_id : t.book_id) === base.id && t.title && t.slug)) {
      v[tr.language_code] = { slug: tr.slug, title: tr.title, body: kind === 'post' ? tr.content : tr.description, excerpt: tr.excerpt || tr.description, seo_title: tr.seo_title, seo_description: tr.seo_description }
    }
    return v
  }

  function emit(kind, base, trs) {
    const urlKind = kind === 'post' ? 'blog' : 'books'
    const v = versions(base, trs, kind)
    const langs = Object.keys(v).filter((l) => LANGS.includes(l))
    for (const lang of langs) {
      const ver = v[lang]
      const path = `p/${urlKind}/${lang}/${encodeURIComponent(ver.slug)}/`
      const canonical = `${BASE}/${path}`
      const alternates = langs.map((l) => ({ lang: l, href: `${BASE}/p/${urlKind}/${l}/${encodeURIComponent(v[l].slug)}/` }))
      const jsonLd = kind === 'post'
        ? { '@context': 'https://schema.org', '@type': 'BlogPosting', headline: ver.title, description: ver.excerpt || undefined, datePublished: ver.date || undefined, inLanguage: lang, mainEntityOfPage: canonical, ...(authorName ? { author: { '@type': 'Person', name: authorName } } : {}) }
        : { '@context': 'https://schema.org', '@type': 'Book', name: ver.title, description: ver.excerpt || undefined, inLanguage: lang, ...(authorName ? { author: { '@type': 'Person', name: authorName } } : {}) }
      const html = page({
        lang, title: ver.seo_title || ver.title, description: ver.seo_description || ver.excerpt || '',
        canonical, alternates, jsonLd,
        bodyHtml: `<article><h1>${esc(ver.title)}</h1><p class="meta">${lang}${ver.date ? ` · ${esc(String(ver.date).slice(0, 10))}` : ''}</p>${md(ver.body)}</article>`,
      })
      write(`${path}index.html`, html)
      count++
    }
  }

  for (const p of (posts ?? []).filter((x) => x.published && x.slug)) emit('post', p, postTrs)
  for (const b of (books ?? []).filter((x) => x.published && x.slug)) emit('book', b, bookTrs)
  console.log(`[prerender] wrote ${count} static language pages for tenant ${tenantId}`)
}

main().catch((e) => { console.warn('[prerender] failed, SPA unchanged:', e.message) })
