// reset-client-password — superadmin-only: resets the password of the admin
// account(s) linked to a tenant. Used when a client forgets their password.
// The service_role key lives ONLY here (Edge Function secret env), never in the frontend.
import { createClient } from 'jsr:@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } })
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  if (req.method !== 'POST') return json({ error: 'method not allowed' }, 405)

  const url = Deno.env.get('SUPABASE_URL')!
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

  // 1) Authenticate the caller with their own JWT
  const authHeader = req.headers.get('Authorization') ?? ''
  const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authHeader } } })
  const { data: { user }, error: authErr } = await userClient.auth.getUser()
  if (authErr || !user) return json({ error: 'unauthenticated' }, 401)

  const admin = createClient(url, serviceKey)

  // 2) Authorize: caller must be a superadmin
  const { data: sa } = await admin.from('tenant_members')
    .select('id').eq('user_id', user.id).eq('role', 'superadmin').maybeSingle()
  if (!sa) return json({ error: 'forbidden' }, 403)

  // 3) Validate input
  let body: { tenant_id?: string; password?: string }
  try { body = await req.json() } catch { return json({ error: 'invalid json' }, 400) }
  const tenantId = body.tenant_id ?? ''
  const password = body.password ?? ''
  if (!/^[0-9a-f-]{36}$/i.test(tenantId)) return json({ error: 'invalid tenant_id' }, 400)
  if (password.length < 8) return json({ error: 'password must be at least 8 characters' }, 400)

  // 4) Find the tenant's admin member(s) — never touch superadmin accounts here
  const { data: members, error: memErr } = await admin.from('tenant_members')
    .select('user_id').eq('tenant_id', tenantId).eq('role', 'admin')
  if (memErr) return json({ error: memErr.message }, 500)
  if (!members?.length) return json({ error: 'no admin account linked to this tenant' }, 404)

  // 5) Reset the password of every admin account of this tenant
  const updated: string[] = []
  for (const m of members) {
    const { error: updErr } = await admin.auth.admin.updateUserById(m.user_id, { password })
    if (updErr) return json({ error: updErr.message }, 400)
    updated.push(m.user_id)
  }

  return json({ ok: true, updated: updated.length })
})
