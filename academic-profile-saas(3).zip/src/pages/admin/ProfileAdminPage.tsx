import { useEffect, useState } from 'react'
import { toast } from 'sonner'
import { useT } from '@/i18n'
import { updateProfile, getProfile } from '@/lib/api'
import { useAdminTenantId } from '@/hooks/useAdminTenant'
import { useSite } from '@/contexts/SiteContext'
import { UploadField } from '@/components/admin/UploadField'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import type { Profile } from '@/types'

// Field component must live OUTSIDE the page component — defining it inside
// makes React remount the input on every keystroke (mobile keyboard closes).
function F({ k, label, dir, form, set }: { k: keyof Profile; label: string; dir?: 'ltr'; form: Profile; set: (k: keyof Profile, v: string) => void }) {
  return (
    <div className="space-y-1.5"><Label>{label}</Label><Input dir={dir} value={(form[k] as string) ?? ''} onChange={(e) => set(k, e.target.value)} /></div>
  )
}

export default function ProfileAdminPage() {
  const t = useT()
  const { refresh } = useSite()
  const [form, setForm] = useState<Profile | null>(null)
  const [busy, setBusy] = useState(false)
  const tid = useAdminTenantId()
  useEffect(() => { getProfile(tid).then(setForm) }, [tid])
  if (!form) return <p className="text-muted-foreground">{t.states.loading}</p>
  const current = form
  const set = (k: keyof Profile, v: any) => setForm((f) => f && { ...f, [k]: v })

  async function save() {
    setBusy(true)
    try { await updateProfile({ ...current, tenant_id: current.tenant_id ?? tid ?? undefined } as Profile); await refresh(); toast.success(t.admin.saved) }
    catch { toast.error(t.admin.saveError) }
    finally { setBusy(false) }
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl gold-text">{t.admin.profile}</h1>
        <Button onClick={save} disabled={busy} className="bg-[#c8a45c] text-stone-900 hover:bg-[#d9b56e]">{busy ? t.admin.saving : t.admin.save}</Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <F form={form} set={set} k="first_name" label={t.admin.form.firstName} />
        <F form={form} set={set} k="last_name" label={t.admin.form.lastName} />
        <F form={form} set={set} k="academic_title" label={t.admin.form.academicTitle} />
        <F form={form} set={set} k="specialty" label={t.admin.form.specialty} />
        <F form={form} set={set} k="institution" label={t.admin.form.institution} />
        <F form={form} set={set} k="field" label={t.admin.form.field} />
        <F form={form} set={set} k="location" label={t.admin.form.location} />
        <F form={form} set={set} k="email" label={t.admin.form.email} dir="ltr" />
        <F form={form} set={set} k="phone" label={t.admin.form.phone} dir="ltr" />
        <F form={form} set={set} k="whatsapp" label={t.admin.form.whatsapp} dir="ltr" />
      </div>
      <div className="space-y-1.5"><Label>{t.admin.form.shortBio}</Label><Textarea rows={3} value={form.short_bio ?? ''} onChange={(e) => set('short_bio', e.target.value)} /></div>
      <div className="space-y-1.5"><Label>{t.admin.form.longBio}</Label><Textarea rows={7} value={form.long_bio ?? ''} onChange={(e) => set('long_bio', e.target.value)} /></div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5"><Label>{t.admin.form.qualifications}</Label><Textarea rows={4} value={(form.qualifications ?? []).join('\n')} onChange={(e) => set('qualifications', e.target.value.split('\n').filter(Boolean))} /></div>
        <div className="space-y-1.5"><Label>{t.admin.form.interests}</Label><Textarea rows={4} value={(form.interests ?? []).join('\n')} onChange={(e) => set('interests', e.target.value.split('\n').filter(Boolean))} /></div>
      </div>
      <UploadField bucket="profile" accept="image/*" value={form.avatar_url ?? ''} onChange={(u) => set('avatar_url', u)} label={t.admin.form.avatar} />
      <h2 className="font-display text-2xl pt-4">{t.sections.links}</h2>
      <div className="grid gap-4 md:grid-cols-2">
        <F form={form} set={set} k="google_scholar" label={t.admin.form.scholar} dir="ltr" />
        <F form={form} set={set} k="orcid" label="ORCID" dir="ltr" />
        <F form={form} set={set} k="researchgate" label="ResearchGate" dir="ltr" />
        <F form={form} set={set} k="linkedin" label="LinkedIn" dir="ltr" />
        <F form={form} set={set} k="facebook" label="Facebook" dir="ltr" />
        <F form={form} set={set} k="x" label="X" dir="ltr" />
        <F form={form} set={set} k="website" label="Website" dir="ltr" />
      </div>
    </div>
  )
}
