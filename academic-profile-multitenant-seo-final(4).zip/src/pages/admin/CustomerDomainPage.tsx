// Domain settings (customer view) — honest status of custom-domain support.
// Shows the customer's current platform URL, any domain rows registered for
// their tenant (read via RLS), DNS guidance, and the real hosting constraint.
// No domain is ever marked active from this page — activation requires the
// existing server-side verification plus routing infrastructure.
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useAdminTenantId } from '@/hooks/useAdminTenant'
import { getTenantPublicUrl } from '@/lib/tenant-url'
import { getWhatsAppRegistrationUrl } from '@/config/contact'
import { useLang, useT } from '@/i18n'
import { Globe, ShieldAlert, MessageCircle } from 'lucide-react'

type DomainRow = { id: string; hostname: string; status: 'pending' | 'verified' | 'active' | 'disabled'; verification_token: string | null }

export default function CustomerDomainPage() {
  const t = useT()
  const { lang } = useLang()
  const tid = useAdminTenantId()
  const [domains, setDomains] = useState<DomainRow[] | null>(null)
  const [slug, setSlug] = useState<string | null>(null)

  useEffect(() => {
    if (!tid || !supabase) return
    let on = true
    supabase.from('tenants').select('slug').eq('id', tid).maybeSingle().then(({ data }) => {
      if (on) setSlug((data as { slug: string } | null)?.slug ?? null)
    })
    supabase.from('tenant_domains').select('id, hostname, status, verification_token').eq('tenant_id', tid)
      .then(({ data }) => { if (on) setDomains((data as DomainRow[] | null) ?? []) })
    return () => { on = false }
  }, [tid])

  const url = slug ? getTenantPublicUrl(slug) : null

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <header>
        <h1 className="font-display text-3xl font-semibold gold-text">{t.admin.domainPage}</h1>
      </header>

      <section className="glass rounded-xl p-6 space-y-2">
        <p className="text-xs text-muted-foreground">{t.admin.domainCurrentUrl}</p>
        {url
          ? <a href={url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 break-all font-mono text-sm gold-text hover:underline" dir="ltr"><Globe className="size-4 shrink-0" />{url}</a>
          : <p className="text-sm text-muted-foreground">{t.states.loading}</p>}
      </section>

      {domains && domains.length > 0 && (
        <section className="glass rounded-xl p-6 space-y-4">
          <p className="font-semibold">{t.admin.domainListTitle}</p>
          {domains.map((d) => (
            <div key={d.id} className="rounded-lg border border-border/60 p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="font-mono text-sm" dir="ltr">{d.hostname}</p>
                <span className="rounded-full border border-[#c8a45c]/40 px-3 py-0.5 text-xs gold-text">
                  {t.admin.domainStatus[d.status]}
                </span>
              </div>
              {d.status === 'pending' && d.verification_token && (
                <div className="mt-3">
                  <p className="text-xs font-semibold text-muted-foreground">{t.admin.dnsTitle}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{t.admin.dnsHint}</p>
                  <code className="mt-2 block break-all rounded bg-secondary px-3 py-2 text-xs" dir="ltr">_academic-verification.{d.hostname} → {d.verification_token}</code>
                </div>
              )}
            </div>
          ))}
        </section>
      )}

      {domains && domains.length === 0 && (
        <p className="text-sm text-muted-foreground">{t.admin.domainNoneYet}</p>
      )}

      <section className="rounded-xl border border-amber-400/30 bg-amber-400/5 px-5 py-4">
        <p className="flex items-start gap-3 text-sm leading-7 text-amber-300">
          <ShieldAlert className="mt-1 size-4 shrink-0" />
          {t.admin.domainHostingNote}
        </p>
      </section>

      <section className="glass rounded-xl p-6">
        <p className="text-sm leading-7 text-muted-foreground">{t.admin.domainContactNote}</p>
        <a href={getWhatsAppRegistrationUrl(lang)} target="_blank" rel="noopener noreferrer"
          className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#c8a45c] px-5 py-2.5 text-sm font-semibold text-[#0c1124] transition-transform hover:scale-[1.03]">
          <MessageCircle className="size-4" /> WhatsApp
        </a>
      </section>
    </div>
  )
}
