import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'
import type { TenantMember } from '@/types'

type AuthCtx = {
  user: User | null
  isAdmin: boolean          // member of any tenant (or legacy admin) — can manage *something*
  isSuperadmin: boolean
  memberships: TenantMember[]
  adminTenantId: string | null  // tenant currently being managed (superadmin "Open Tenant" context)
  setAdminTenantId: (id: string | null) => void
  canManage: (tenantId?: string | null) => boolean
  loading: boolean
  signIn: (email: string, password: string) => Promise<string | null>
  signOut: () => Promise<void>
}

const Ctx = createContext<AuthCtx>({
  user: null, isAdmin: false, isSuperadmin: false, memberships: [],
  adminTenantId: null, setAdminTenantId: () => {}, canManage: () => false,
  loading: true, signIn: async () => null, signOut: async () => {},
})
export const useAuth = () => useContext(Ctx)

const MGMT_KEY = 'admin_tenant_id'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [memberships, setMemberships] = useState<TenantMember[]>([])
  const [legacyAdmin, setLegacyAdmin] = useState(false)
  const [adminTenantId, setAdminTenantIdState] = useState<string | null>(() => sessionStorage.getItem(MGMT_KEY))
  const [loading, setLoading] = useState(Boolean(supabase))

  const isSuperadmin = memberships.some((m) => m.role === 'superadmin')
  const isAdmin = isSuperadmin || legacyAdmin || memberships.length > 0

  const setAdminTenantId = (id: string | null) => {
    setAdminTenantIdState(id)
    if (id) sessionStorage.setItem(MGMT_KEY, id); else sessionStorage.removeItem(MGMT_KEY)
  }

  const canManage = (tenantId?: string | null) =>
    isSuperadmin || legacyAdmin || (!!tenantId && memberships.some((m) => m.tenant_id === tenantId))

  async function loadRoles(u: User | null) {
    if (!supabase || !u) { setMemberships([]); setLegacyAdmin(false); return }
    const [{ data: m }, { data: a }] = await Promise.all([
      supabase.from('tenant_members').select('*').eq('user_id', u.id),
      supabase.from('admin_users').select('user_id').eq('user_id', u.id).maybeSingle(),
    ])
    setMemberships((m as TenantMember[]) ?? [])
    setLegacyAdmin(Boolean(a))
  }

  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => {
      const u = data.session?.user ?? null
      setUser(u)
      loadRoles(u).finally(() => setLoading(false))
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      const u = session?.user ?? null
      setUser(u)
      loadRoles(u)
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  async function signIn(email: string, password: string) {
    if (!supabase) return 'demo'
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return error ? error.message : null
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut()
    setUser(null); setMemberships([]); setLegacyAdmin(false); setAdminTenantId(null)
  }

  return (
    <Ctx.Provider value={{ user, isAdmin, isSuperadmin, memberships, adminTenantId, setAdminTenantId, canManage, loading, signIn, signOut }}>
      {children}
    </Ctx.Provider>
  )
}
